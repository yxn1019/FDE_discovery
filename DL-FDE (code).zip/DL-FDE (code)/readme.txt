1. Run NN_pde.py/NN_ode.py/NN_pt.py for training data.

2. Run fPDE_discovery_de.py/foDE_discovery_de.py/fpt_discovery_de.py for fractional PDE.

*fSTRidge/fptSTRidge/foSTRidge.py , which act as the function integrated in fPDE_discovery_de.py etc. are used as generating library and optimizing linear coefficients via well-known STRidge.py.
 