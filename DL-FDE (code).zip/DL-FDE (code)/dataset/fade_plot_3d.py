# -*- coding: utf-8 -*-
"""
Created on Wed Nov  6 10:42:51 2024

@author: 54543
"""

# locals().clear()
import numpy as np
import torch
from torch.nn import Linear,Tanh,Sequential
import torch.nn.functional as F
from torch.autograd import Variable
import matplotlib.pyplot as plt
import torch.nn as nn
import random
import torch.nn.functional as func
import scipy.special as sp
from STRidge import *
#%%

def fractional_integral(f, alpha, w, b):
    # f: Function for which is computed by the Caputo fractional derivative
    # alpha: Fractional integral order, the derivative order is n-alpha 
    # a, b: Interval for the integral approximation
    # n: Number of quadrature points
    # Calculate the Jacobi-Gauss quadrature points and weights in the interval (a, b)
    if alpha>1.:
        # x, w = sp.roots_jacobi(n, 0, 1-alpha) 
        # t = b-b/2*(x+1) # transform variable
        # Compute the Caputo fractional derivative using the quadrature approximation
        result = np.matmul(f,w.reshape(-1,1))/sp.gamma(2-alpha)*(b/2)**(2-alpha)
    else:# i.e. 0<alpha<1
        # x, w = sp.roots_jacobi(n, 0, -alpha) 
        # t = b-b/2*(x+1) # transform variable
        result = np.matmul(f,w.reshape(-1,1))/sp.gamma(1-alpha)*(b/2)**(1-alpha)   
    # print('caputo=',result)
    return result
class LearnableGaussianActivation(nn.Module):
    def __init__(self):
        super(LearnableGaussianActivation, self).__init__()
        # Initialize learnable parameters mu and sigma
        self.mu = nn.Parameter(torch.randn(1))  # Mean parameter
        self.sigma = nn.Parameter(torch.ones(1))  # Standard deviation parameter

    def forward(self, x):
        # Gaussian function: exp(-(x - mu)^2 / (2 * sigma^2))
        return torch.exp(-((x - self.mu) ** 2) / (2 * self.sigma ** 2))
    
#%%   
# folderpath = "dataset/"
# filename = r"Convection_diffusion.dat"
# filename = r"FMIM.dat"
filename = r"dataset/tsfade_fft.dat"
# filename = r"tsfade_fdm.dat"
# filepath = os.path.join(folderpath, filename)
x=torch.arange(0,30,0.25)
t=torch.arange(0,15,0.1)
noise_level = 25  # percentage of noise
pos = []
x_num=len(x)
t_num=len(t)
total=x_num*t_num   #Num of total data

un=np.ones([t_num,x_num])
j=0
unm=0
with open(filename, 'r') as file_to_read:
    while True:
        lines = file_to_read.readline() # 整行读取数据
        for line in lines.split():
            pos.append(line)
        for i in range(len(pos)):
            un[j,i]=float(pos[i])
        pos=[]
        j+=1
        unm+=1
        if not lines:
            break
        
# data = io.loadmat('dataset/tsfade_fft.mat')
# un = np.real(data['Exact'])
# x = np.real(data['x'][0])
# t = np.real(data['t'][0])

#-----------------Preparing Training and Validate Dataset
un_raw=torch.from_numpy(un.astype(np.float32))
data=torch.zeros(2)
h_data=torch.zeros([total,1])
database=torch.zeros([total,2])
num=0
for i in range(t_num):
    for j in range(x_num):
        data[0]=x[j]
        data[1]=t[i]
        h_data[num]=un[i,j]*(1+0.01*noise_level*np.random.uniform(-1,1))  #Add noise
        database[num]=data
        num+=1

#%% Neural Network
# Net = Sequential(
#     Linear(2, 20),
#     LearnableGaussianActivation(),  # Custom Gaussian activation
#     Linear(20, 20),
#     LearnableGaussianActivation(),
#     Linear(20, 20),
#     LearnableGaussianActivation(),
#     Linear(20, 20),
#     LearnableGaussianActivation(),
#     Linear(20, 20),
#     LearnableGaussianActivation(),
#     Linear(20, 1)
# )
    #Neural Network
Net = Sequential(
    Linear(2, 20),
    Tanh(),
    Linear(20, 20),
    Tanh(),
    Linear(20, 20),
    Tanh(),
    Linear(20, 20),
    Tanh(),
    Linear(20, 20),
    Tanh(),
    Linear(20, 20),
    Tanh(),
    Linear(20, 20),
    Tanh(),
    Linear(20, 20),
    Tanh(),
    Linear(20, 1),
)
#Generating meta-data
n = 5 # Number of quadrature points
alpha = 0.99 # time fractional order
beta = 1.5 # space fractional order

num=0
Net.load_state_dict(torch.load('model_save/draft-2000-25/draft-20000.pkl'))
x=torch.arange(0., 30, 0.1)
t=torch.arange(3., 15, 0.1)

x_num=len(x)
t_num=len(t)
total = x_num*t_num
t_n = t.data.numpy()
x_n = x.data.numpy()
if 0<alpha<1:
    t_gj, w_gj = sp.roots_jacobi(n, 0, -alpha) # G-J points, 0<alpha<1
if 1<beta<2:
    x_gj, v_gj = sp.roots_jacobi(n, 0, 1-beta) # G-J points, 1<alpha<2

data = torch.zeros(2)
h_data = torch.zeros([total,1])
database = torch.zeros([total,2])
database_tf = torch.zeros([total*n,2])
database_sf = torch.zeros([total*n,2])

for i in range(t_num):
    for j in range(x_num):
        data[0]=x[j]
        data[1]=t[i]
        database[num]=data
        num+=1

for i in range(total):
    database_tf[i*n:i*n+n,1] = database[i,1]-database[i,1]/2*(t_gj+1)
    database_tf[i*n:i*n+n,0] = database[i,0]
    database_sf[i*n:i*n+n,0] = database[i,0]-database[i,0]/2*(x_gj+1)
    database_sf[i*n:i*n+n,1] = database[i,1]
 
#%% 
c = Net(database).data.numpy().reshape(t_num,x_num)
un_noise = h_data.data.numpy().reshape(t_num,x_num)
fig1 = plt.figure()
fig2 = plt.figure()
ax1 = fig1.add_subplot(projection='3d')
ax2 = fig2.add_subplot(projection='3d')
X, T = np.meshgrid(x,t) #mesh for train
ax1.plot_surface(T, X, c, cmap='viridis') #NN模拟值
# plt.figure()
ax2.scatter(T, X, un_noise,               #加噪精确解
            facecolors = 'none', 
            marker = '*', 
            edgecolor = 'k', 
            s = 30,
            # label = 'Exact'
            )
# ax2.set_xlabel(r'$T$')
# ax2.set_ylabel(r'$X$')

# ax2.set_zlabel(r'$u$')


plt.show()
