# -*- coding: utf-8 -*-
"""
Created on Mon Jul  1 22:04:54 2024

@author: 54543
"""
# locals().clear()
import numpy as np
import torch
from torch.nn import Linear,Tanh,Sequential
import torch.nn.functional as F
from torch.autograd import Variable
import matplotlib.pyplot as plt
import torch.nn as nn
import random
import torch.nn.functional as func
import scipy.special as sp
# from STRidge import *
from scipy.optimize import differential_evolution as de
from scipy.optimize import minimize
from fptSTRidge import *
import matplotlib.pyplot as plt
from scipy.linalg import solve_banded


#%%
# Optimizer

# 目标函数，用于计算模拟数据与实际数据的误差
def objective_function(params):
    global iter
    noise_level = 0
    alpha, beta = params
    w,err = fptSTRidge(alpha, beta, noise_level)
    # 计算最后时刻的模拟数据与实际数据的aic
    print(f'Iteration {iter}: loss = {err:.6f}, alpha = {alpha:.6f}, beta = {beta:.6f}')
    # if iter%10==0:
    print(w.T)
    iter = iter+1
    return err

np.random.seed(42)# 设置一些示例数据

# Initial guess for parameters
iter = 1
bounds=[(0.01, 0.99),(1.01, 1.99)]
# 优化
result = de(objective_function
            ,bounds
            ,maxiter=5 # (maxiter+1)*num_pop*num_para, if maxiter=2, then times=60
            ,tol=1e-4
            , disp=True
            )
# 优化结果
# result = minimize(objective_function, result.x, method='Powell', bounds=[(0.01, 0.99), (1.01, 1.99)])
alpha_opt, beta_opt = result.x
w,_ = fptSTRidge(alpha_opt, beta_opt)
#%%
print(f"best parameters: alpha = {alpha_opt:.5f}, beta = {beta_opt:.5f}")
print(f'best loss: {result.fun}')
# 方程参数
print(w)

